This demo makes The Plot for a single scan.

To make the plot, from the /PLOTDEMO directory, in shell, type:
$ generate_masks.csh

And then once that’s done, in the same directory, using Matlab type:
>> plotdemo()

You will see The Plot on the screen, and it will save to an /output folder



Files provided:
/PLOTDEMO
  /data - a BOLD run and an in-register FreeSurfer segmentation. generate_masks.csh works on the segmentation to create more mask files
  /libraries - just a few Matlab scripts needed to read in nifti format files
  /output - created by the plotdemo.m script, where The Plot will appear



NOTE:
generate_masks.csh uses AFNI to perform erosions and resampling
plotdemo.m uses FSL commands to obtain header information when reading in nifti files
So you need AFNI and FSL installed and on your path for this stuff to work

