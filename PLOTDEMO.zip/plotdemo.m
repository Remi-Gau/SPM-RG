function plotdemo(varargin)

% This is a little script to create The Plot. First you need to run
% "generate_masks.csh", which requires AFNI. This makes the
% FreeSurfer-based masks used to bin voxels for The Plot. Then you just run
% this script and a plot will result.
%
% IMPORTANT
% You need FSL installed because this script makes system calls to 'fslhd'
%
% You also need to put the NifTI matlab library on your matlab path
%   (the library is included in this folder and is added right below here)
%
% This script was developed on a mac system, it wasn't tested on Windows.

% get paths
pdir=pwd;
addpath(genpath([pwd]));


% prepare the output directory
odir = [pdir '/output'];
system(['mkdir -p ' odir]);

% load the images in RAS orientation
fname.bold=[ pdir '/data/bold1_at_EPI.nii.gz'];
img.bold=nii_give_RAS(fname.bold);

% load the compartment masks in RAS orientation
fname.gmribbon=[ pdir '/data/aparc+aseg.atlas.GM_RIBBONMASK_ero0_EPI.nii.gz'];
fname.gmcblm=[ pdir '/data/aparc+aseg.atlas.GM_CBLMMASK_ero0_EPI.nii.gz'];
fname.gmsc=[ pdir '/data/aparc+aseg.atlas.GM_SCMASK_ero0_EPI.nii.gz'];
mask.gm_r=nii_give_RAS(fname.gmribbon);
mask.gm_cbl=nii_give_RAS(fname.gmcblm);
mask.gm_sc=nii_give_RAS(fname.gmsc);

fname.wmero0=[ pdir '/data/aparc+aseg.atlas.WMMASK_ero0_EPI.nii.gz'];
fname.wmero2=[ pdir '/data/aparc+aseg.atlas.WMMASK_ero2_EPI.nii.gz'];
fname.wmero4=[ pdir '/data/aparc+aseg.atlas.WMMASK_ero4_EPI.nii.gz'];
mask.wmmask0=nii_give_RAS(fname.wmero0);
mask.wmmask2=nii_give_RAS(fname.wmero2);
mask.wmmask4=nii_give_RAS(fname.wmero4);
mask.wmero4=mask.wmmask4;
mask.wmero2to4=mask.wmmask2-mask.wmmask4;
mask.wmero0to2=mask.wmmask0-mask.wmmask2;

fname.csfero0=[ pdir '/data/aparc+aseg.atlas.CSFMASK_ero0_EPI.nii.gz'];
fname.csfero2=[ pdir '/data/aparc+aseg.atlas.CSFMASK_ero2_EPI.nii.gz'];
mask.csfmask0=nii_give_RAS(fname.csfero0);
mask.csfmask2=nii_give_RAS(fname.csfero2);
mask.csfero2=mask.csfmask2;
mask.csfero0to2=mask.csfmask0-mask.csfmask2;

mask.gm_r=~~mask.gm_r;
mask.gm_cbl=~~mask.gm_cbl;
mask.gm_sc=~~mask.gm_sc;

mask.wmero4=~~mask.wmero4;
mask.wmero2to4=~~mask.wmero2to4;
mask.wmero0to2=~~mask.wmero0to2;

mask.csfero2=~~mask.csfero2;
mask.csfero0to2=~~mask.csfero0to2;


% flatten and detrend the bold image
dd=size(img.bold);
im=reshape(img.bold,[dd(1)*dd(2)*dd(3) dd(4)]);

% mean and trend regressors
r0=ones(1,dd(4));
r1=linspace(0,1,dd(4));

% also set up a temporal mask ignoring the first 4 volumes
tmask=r0;
tmask(1:4)=0;

% remove those terms
im=myregress([r0;r1],im,~~tmask);




% create the basic plot
img.masterflat=im;


gm_r=img.masterflat(mask.gm_r(:),:);
gm_sc=img.masterflat(mask.gm_sc(:),:);
gm_cbl=img.masterflat(mask.gm_cbl(:),:);

wm_ero4=img.masterflat(mask.wmero4(:),:);
wm_ero2to4=img.masterflat(mask.wmero2to4(:),:);
wm_ero0to2=img.masterflat(mask.wmero0to2(:),:);

csf_ero2=img.masterflat(mask.csfero2(:),:);
csf_ero0to2=img.masterflat(mask.csfero0to2(:),:);

sz.gm_r=size(gm_r,1);
sz.gm_sc=size(gm_sc,1);
sz.gm_cbl=size(gm_cbl,1);
sz.wmero4=size(wm_ero4,1);
sz.wmero2to4=size(wm_ero2to4,1);
sz.wmero0to2=size(wm_ero0to2,1);
sz.csfero0to2=size(csf_ero0to2,1);
sz.csfero2=size(csf_ero2,1);

redlimz=sz.gm_r+sz.gm_cbl+sz.gm_sc;

allmat=[gm_r; gm_sc; gm_cbl; wm_ero0to2; wm_ero2to4; wm_ero4; csf_ero0to2; csf_ero2];


sett.gsclr=[0 0 0];
sett.gmclr=[0 .5 1];
sett.wmclr=[0 1 0];
sett.csfclr=[1 1 0];
sett.lw=2;
gmlimz=[-20 20];
xlimz=[1 dd(4)];

close all;
h=figure;
set(h,'position',[100 100 1920 1080]);
set(h,'visible','on');


% plot head motion at top
fd=load([pdir '/data/fd.txt']);
subplot(5,1,1);
plot([1:dd(4)],fd,'r');
xlim([1 dd(4)]);
ylim([0 2]);
set(gca,'ytick',[0 2]);
title('Head motion');
ylabel('Framewise Displacement (mm)');


% the heatmap
subplot(5,1,[2:5]);

imagesc(allmat,gmlimz);
set(gca,'ytick',[]);
colormap(gray);
hh=hline(redlimz(1),'g');
set(hh,'linewidth',2);
xlim(xlimz);
title('Timeseries of in-brain voxels, arranged by FreeSurfer-based compartment masks');
ylabel('Voxels');
xlabel('Volume #');

stx=0; endx=2;
sty=0; endy=sz.gm_r;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.4*sett.gmclr);

sty=sz.gm_r; endy=sz.gm_r+sz.gm_sc;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.6*sett.gmclr);

sty=sz.gm_r+sz.gm_sc; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.8*sett.gmclr);


sty=sz.gm_r+sz.gm_sc+sz.gm_cbl; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.8*sett.wmclr);

sty=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.6*sett.wmclr);

sty=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4+sz.wmero4;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.4*sett.wmclr);

sty=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4+sz.wmero4; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4+sz.wmero4++sz.csfero0to2+sz.csfero2;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',sett.csfclr);



stx=xlimz(end)-1; endx=xlimz(end)+1;
sty=0; endy=sz.gm_r;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.4*sett.gmclr);

sty=sz.gm_r; endy=sz.gm_r+sz.gm_sc;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.6*sett.gmclr);

sty=sz.gm_r+sz.gm_sc; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.8*sett.gmclr);


sty=sz.gm_r+sz.gm_sc+sz.gm_cbl; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.8*sett.wmclr);

sty=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.6*sett.wmclr);

sty=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4+sz.wmero4;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',.4*sett.wmclr);

sty=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4+sz.wmero4; endy=sz.gm_r+sz.gm_sc+sz.gm_cbl+sz.wmero0to2+sz.wmero2to4+sz.wmero4+sz.csfero0to2+sz.csfero2;
v=[stx sty; stx endy; endx endy; endx sty];
f=[1 2 3 4];
patch('Faces',f,'Vertices',v,'FaceColor',sett.csfclr);


oname = [odir '/plot.png'];
set(h,'paperpositionmode','auto');
print(gcf,'-dpng',oname);


















%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [img dims o]=nii_give_RAS(im,varargin)

% NIFTI qform and sform codes are relative to RAS
%
% does not matter which code used for showing the arrays
% but we do want to flip the arrays to be RAS or close to it
%
% also we need to scale the image, sometimes uint8 and a scaling factor are used to save space instead of single or double (float)
%
% If a filename or structure is given as the sole input, it returns the
% RAS-oriented 4D array of the input as a double
%
% If an additional array is provided, this array is converted from RAS to
% the orientation of the first input but is otherwise not touched


if ischar(im)
    % if a filename given
    tmp=load_untouch_nii(im);
else
    % if a cell array given (from load_untouch_nii)
    tmp=im;
    im=tmp.fileprefix;
end

% if flipping RAS to the original orientation
if ~isempty(varargin)
    tmp.img=varargin{1,1};
end

tmp.img=double(tmp.img);

if isempty(varargin)
if tmp.hdr.dime.scl_slope~=0
    fprintf('Rescaling the image\n');
    tmp.img=double(tmp.img)*tmp.hdr.dime.scl_slope+tmp.hdr.dime.scl_inter;
end
end

dims=tmp.hdr.dime.pixdim(2:4);

[jk o.sx]=system(['fslhd ' im ' | grep sform_xorient | awk ''{print $2}''' ]); o.sx(end)=[];
[jk o.sy]=system(['fslhd ' im ' | grep sform_yorient | awk ''{print $2}''' ]); o.sy(end)=[];
[jk o.sz]=system(['fslhd ' im ' | grep sform_zorient | awk ''{print $2}''' ]); o.sz(end)=[];
[jk o.scode]=system(['fslhd ' im ' | grep sform_code | awk ''{print $2}''' ]); o.scode(end)=[]; o.scode=str2num(o.scode);
[jk o.sRx]=system(['fslhd ' im ' | grep sto_xyz:1 | awk ''{print $2 " " $3 " " $4}''' ]); o.sRx(end)=[]; o.sR(1,1:3)=str2num(o.sRx);
[jk o.sRy]=system(['fslhd ' im ' | grep sto_xyz:2 | awk ''{print $2 " " $3 " " $4}''' ]); o.sRy(end)=[]; o.sR(2,1:3)=str2num(o.sRy);
[jk o.sRz]=system(['fslhd ' im ' | grep sto_xyz:3 | awk ''{print $2 " " $3 " " $4}''' ]); o.sRz(end)=[]; o.sR(3,1:3)=str2num(o.sRz);


[jk o.qx]=system(['fslhd ' im ' | grep qform_xorient | awk ''{print $2}''' ]); o.qx(end)=[];
[jk o.qy]=system(['fslhd ' im ' | grep qform_yorient | awk ''{print $2}''' ]); o.qy(end)=[];
[jk o.qz]=system(['fslhd ' im ' | grep qform_zorient | awk ''{print $2}''' ]); o.qz(end)=[];
[jk o.qcode]=system(['fslhd ' im ' | grep qform_code | awk ''{print $2}''' ]); o.qcode(end)=[]; o.qcode=str2num(o.qcode);
[jk o.qRx]=system(['fslhd ' im ' | grep qto_xyz:1 | awk ''{print $2 " " $3 " " $4}''' ]); o.qRx(end)=[]; o.qR(1,1:3)=str2num(o.qRx);
[jk o.qRy]=system(['fslhd ' im ' | grep qto_xyz:2 | awk ''{print $2 " " $3 " " $4}''' ]); o.qRy(end)=[]; o.qR(2,1:3)=str2num(o.qRy);
[jk o.qRz]=system(['fslhd ' im ' | grep qto_xyz:3 | awk ''{print $2 " " $3 " " $4}''' ]); o.qRz(end)=[]; o.qR(3,1:3)=str2num(o.qRz);

if o.scode>0
    if ~isempty(varargin)
        [img perm]=perm_and_flip(tmp,o.sR,1);
    else
        [img perm]=perm_and_flip(tmp,o.sR);
    end
elseif o.qcode>0
    if ~isempty(varargin)
        [img perm]=perm_and_flip(tmp,o.qR,1);
    else
        [img perm]=perm_and_flip(tmp,o.qR);
    end
else
    fprintf('ERROR WARNING in nii_give_RAS.m: qformcode and sformcode of %s are both 0 so conversion to RAS is unknown',niifile);
end

if numel(perm)==4
    perm(4)=[];
end
dims=dims(perm);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [img perm] = perm_and_flip(tmp,R,varargin)

% define the principal directions
signR=sign(R);
absR=abs(R);

[s ss]=sort(absR(:));
s3(ss)=[1:9];
s3=reshape(s3,[3 3]);
topR=zeros(3,3);
[a b]=find(s3==max(s3(:)));
s3(a,:)=[0 0 0];
s3(:,b)=[0 0 0]';
topR(a,b)=1;
[a b]=find(s3==max(s3(:)));
s3(a,:)=[0 0 0];
s3(:,b)=[0 0 0]';
topR(a,b)=1;
[a b]=find(s3==max(s3(:)));
s3(a,:)=[0 0 0];
s3(:,b)=[0 0 0]';
topR(a,b)=1;



flipR=topR.*signR;
% this is to go from RAS to original orientation
if ~isempty(varargin)
    flipR=inv(flipR);
end

for i=1:3
    [jk perm(i) flipr(i) ]=find(flipR(i,:));
end

% have to preserve the time dimensions explicitly if present
d=size(tmp.img);
if numel(d)>3
    perm(4)=4;
end


img=permute(tmp.img,perm);

% now flip where needed to get RAS
for i=1:3
    if flipr(i)<0
        img=flipdim(img,i);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [img]=showbrik(V,orien,slc,t,varargin)

%d1ATL: left to right; front down; bottom left
%d2ATL: back to front; left top; bottom left
%d3ATL: bottom to top; left top; front right
%d1EPI: left to right; front down; bottom left
%d2EPI: back to front; left top; bottom left
%d3EPI: bottom to top; left top; front right

% presumes RAS orientation, just saying.

switch orien
    case 'side' % rot 90 ccw: L=back;R=front; T=top; B=down
        img=(rot90(squeeze(V(slc,:,:,t))));
    case 'front' % rot 90 ccw: L=left; R=right; T=top; B=down
        img=(rot90(squeeze(V(:,slc,:,t))));
    case 'top' % rot 90 ccw: L=left; R=right; T=front; B=back
        img=(rot90(squeeze(V(:,:,slc,t))));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%I
function [ming]=multslc(V,orien,slcz,t,varargin)

ming=[];

for z=1:numel(slcz)
    [img]=showbrik(V,orien,slcz(z),t);
    if isempty(varargin) | varargin{1,1}==0
        ming=[ming img];
    else
        ming=[ming; img];
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [rgbval] = convert2rgb(tmp,scl,varargin)

% tmp is an image
% scl is like jet or copper or self-made
% varargin is limits for scaling the image



%if varargin then we're scaling image
if ~isempty(varargin)
    minz=varargin{1,1}(1);
    maxz=varargin{1,1}(2);
    
    % add an extra column with limits
    tmp=[tmp zeros(size(tmp,1),1)];
    tmp(end,end)=minz;
    tmp(end-1,end)=maxz;
    
    tmp(tmp<minz)=minz;
    tmp(tmp>maxz)=maxz;
    tmp=tmp-min(tmp(:));
    tmp=tmp/max(tmp(:));
    tmp=uint8(tmp*256);
    
    % delete the extra column
    tmp(:,end)=[];
else
    tmp=tmp-min(tmp(:));
    tmp=tmp/max(tmp(:));
    tmp=uint8(tmp*256);
end
rgbval=ind2rgb(tmp,scl);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [nimg] = olay(bimg,timg,msk)

% overlay one image on another

msk=~~msk;
msk=repmat(msk,[1 1 size(bimg,3)]);
nimg=bimg;
nimg(msk)=timg(msk);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [resid pred b] = removepoly(tc,ord,varargin)

% remove legendre polynomials up to ORD
% 0 - mean
% 1 - trend
% 2 - bow
% 3 - sinusoid
% 4 - w-shape
% 5 - w-sinusoid
% etc etc
%
% be careful, these are high-pass filters also

% presumes tc is vox x time

% tmask is 1 when used, 0 when censored

d=size(tc);

for i=0:ord
    b=legendre(i,linspace(-1,1,d(2)));
    if i==0
        r=b(1,:);
    else
        r=[r; b(1,:)];
    end
end


if isempty(varargin)
    % use all timepoints
    b=r'\tc';
    pred=r'*b;
    resid=tc-pred';
    
else
    % use only specified timepoints
    tmask=~~varargin{1,1};
    b=r(:,tmask)'\tc(:,tmask)';
    pred=r'*b;
    resid=tc-pred';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [resid pred b]=myregress(r,tc,varargin)

% presumes vox x time input variable structure

if isempty(varargin)
    % use all timepoints
    b=r'\tc';
    pred=r'*b;
    resid=tc-pred';
    
else
    % use only specified timepoints
    tmask=varargin{1,1};
    b=r(:,tmask)'\tc(:,tmask)';
    pred=r'*b;
    resid=tc-pred';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







