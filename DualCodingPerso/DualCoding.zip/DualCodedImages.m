% Structural must have same dimension as the functionnal (or the other way
% around if you want smoother images - reslice one or the other);

%% INITIALIZE
close all; clear all; clc;

% Folders for the structural
StructuralFolder = fullfile(pwd, 'Structural');
% Name of the structural file on which the activations will be drawn
StructuralFile = fullfile(StructuralFolder, 'MeanStructural.nii');

ExperimentFolder = fullfile(pwd, 'Non_McGurk_Auditory_Answers');


% Images drawn on a white background
BkGrd = 1;
% Threshold to make the background of the structural white: any voxel with
% a value below the maximum value of the structural divided by this
% threshold will be white.
% You might have to play around a bit with this to get it right.
BkGrdThrshld = 15;


% Enter here the coordinates [X Y Z] of the activations of interested you want
% pictures of. Several activations can entered: one per line.
CoordinatesOfInterest = [-60 10 20];


% if several slices must be plotted around an activation
NumberOfSlices = 1; % How many besides the slice of interest. 
% Must be an odd number : always X slices before and after the slice of interest.
% How many slices should be skipped between the slice of interest amd the 
% previous and following ones. Has to be compatible with the NumberOfSlice
% value
Slice2Skip = 2;  


% Orientation of the slices to be plotted. 1=sagittal, 2=frontal, 3=axial
% Can be any combinations of the 3.
View = 1:3;


% Dimension for the figures: [x y width height] will be adapted later
% depending on volume size
Dimension = repmat([0.3 0.4 0.35 0.35],3,1);


% Contrast to plot
ContrastNumber = 2;


% Transparency of the t-value
Transparency = 1;
% Plot only the positive (1), negative values (-1) or all of them (0)
Values2Plot = 1;
% T Threshold for the peak activation values. Get from SPM results.
Threshold = 4;
% Set the Min/Max T-values for alpha coding
A_range = [0 Threshold];
% Voxels with t-stats of 0 will be completely transparent; 
% Voxels with t-stat magnitudes greater or equal than the threshold will be opaque.
if ~Transparency
    A_range = [A_range(2)-0.001 A_range(2)];
end
% Choose a colormap for the overlay
if Values2Plot==0
    % cool, autumn, spring, summer, winter, hsv
    CM_over = jet(256);
    %CM_over = CM_over(:, [2 1 3]);
    %CM_over = CM_over(:, [3 1 2]);
    %CM_over = CM_over(:, [1 3 2]);
    
else
    CM_over = hot(256);
    
    %CM_over = CM_over(:, [2 1 3]);
    %CM_over = CM_over(:, [3 1 2]);
    %CM_over = CM_over(:, [1 3 2]); 
    %CM_over = CM_over(:, [2 3 1]); 
    %CM_over = hsv(256);
end


% CONTOUR 
Contour=1;
% Above a certain threshold (expressed in t values)
ContourThreshold = 3.5;
% Or around certain clusters
ContourFile = ''; %#ok<NA%#ok<MSNU> SGU>
%EXAMPLES
% ContourFile = fullfile(ExperimentFolder, 'INC_A_sup2_CON_A_p_0.01_c_500.img');


% ROI
% if you want to mask or weight the activations to draw, specify here the 
% mask/weight images corresponding to each contrast.
ROI_File=''; %#ok<NA%#ok<MSNU> SGU>
%EXAMPLES
%ROI_File = fullfile(ExperimentFolder, 'INC_A_sup2_CON_A_p_0.01_c_500.img');             


% Print figures as tif
PrintFig = 0;
FirstFig = 1;


% Set the labels for the colorbar
hue_label = 'Beta Difference (CON_Block - INC_Block)';
alpha_label = '|t|';


%% STRUCTURAL
Structural = spm_read_vols(spm_vol(StructuralFile));

% Choose a colormap for the underlay
CM_under = gray(256);
% Set the Min/Max values for structural
AbsMaxStruc = max(abs(Structural(:)));
H_RangeStruc = [0 AbsMaxStruc];
if BkGrd
    Structural(Structural<mean(Structural(:))/BkGrdThrshld) = AbsMaxStruc;
    Color = 'w';
else
    Color = 'k'; %#ok<UNRCH>
end

clear AbsMaxStruc


%% FUNCTIONAL
try
    % load the SPM.mat
    load(fullfile(ExperimentFolder, 'SPM.mat'))
    % display the name of the contrasts to plot
    SPM.xCon(ContrastNumber).name
catch
end

if length(num2str(ContrastNumber))<2
    ContrastNumber = strcat('0', num2str(ContrastNumber));
end

BetaDifferenceFile = fullfile(ExperimentFolder, strcat('con_00', ContrastNumber, '.img'));
                      
TValuesFile = fullfile(ExperimentFolder, strcat('spmT_00', ContrastNumber, '.img'));                      


%% Beta image
BetaDifference = spm_read_vols(spm_vol(BetaDifferenceFile));
BetaDifference(isnan(BetaDifference)) = 0; % Remove NaN values and sets them to zero
if Values2Plot>0
    BetaDifference(BetaDifference<0)=0;
elseif Values2Plot<0
    BetaDifference(BetaDifference>0)=0;
end

% Set actual dimension for the figures depending on the dimension of the
% images
ImgInfo = spm_vol(BetaDifferenceFile);
ImageDim = ImgInfo(1).dim %#ok<NOPTS>
Position = Dimension.*[1 1 ImageDim(2)/ImageDim(1) ImageDim(3)/ImageDim(1); ...
                       1 1 1                       ImageDim(3)/ImageDim(1); ...
                       1 1 1                       ImageDim(2)/ImageDim(1)];
                   
% Getting the coordinates of the voxel of interest
CoordinatesOfInterest(:,end+1) = 1;
Transf_Matrix = spm_get_space(BetaDifferenceFile);
VoxelsOfInterest = [];
for i=1:size(CoordinatesOfInterest,1) 
    VoxelsOfInterest(i,:) = inv(Transf_Matrix)*CoordinatesOfInterest(i,:)'; %#ok<MINV>
end
VoxelsOfInterest(:,4)=[] %#ok<NOPTS>
                   

%% T image                   
TValues = spm_read_vols(spm_vol(TValuesFile));
if Values2Plot>0
    TValues(TValues<0)=0;
elseif Values2Plot<0
    TValues(TValues>0)=0;
end

if (size(BetaDifference)~=size(TValues) | size(BetaDifference)~=size(Structural)) %#ok<OR2>
    error('\n\n Images have different sizes. \n\n')
end

%% Contour
if Contour && ~strcmp(ContourFile,'')
    Contour_Mask = spm_read_vols(spm_vol(ContourFile));
    if size(BetaDifference)~=size(Contour_Mask)
        error('\n\n Images have different sizes. \n\n')
    end
end

%% ROI
if ~strcmp(ROI_File,'')
    ROI_Mask = spm_read_vols(spm_vol(ROI_File));
    if size(BetaDifference)~=size(ROI_Mask)
        error('\n\n Images have different sizes. \n\n')
    end
    BetaDifference(ROI_Mask==0)=0;
    TValues(ROI_Mask==0)=0;
    Contour_Mask(ROI_Mask==0)=0;
end



%% Select the slices and decide on the range of values to plot
SliceRange = [];
Submax = [];
for i=1:length(View)
    
    % Get the range of slices to plot in each dimension
    A = [];
    if NumberOfSlices==1
        SliceRange(View(i),:) = VoxelsOfInterest(:,View(i));
    else
        for j=1:size(VoxelsOfInterest,1)
            A = [ A ...
                  VoxelsOfInterest(j,View(i))-Slice2Skip*(NumberOfSlices)/2 : ...
                  Slice2Skip : ...
                  VoxelsOfInterest(j,View(i))+Slice2Skip*(NumberOfSlices)/2];
        end
        SliceRange(View(i),:) = A;
    end
    
    % Gets the maximum beta value to plot
    switch View(i)
        case 1
           TEMP = abs(BetaDifference(SliceRange(1,:),:,:));
        case 2
           TEMP = abs(BetaDifference(:,SliceRange(2,:),:));
        case 3
           TEMP = abs(BetaDifference(:,:,SliceRange(3,:)));
    end
    Submax = [Submax max(TEMP(:))];
    clear TEMP
    
end
 
% Set the Min/Max values for hue coding
% Submax = max(abs(BetaDifference(:)))
absmax = max(Submax);
switch Values2Plot
    case 0
        H_range = [-absmax absmax]; % The colormap is symmetric around zero
    case 1
        H_range = [0 absmax];
    case -1
        H_range = [-absmax 0];
end
      

%% Plotting

for i=1:length(View)
    
    SliceRange(View(i),:) %#ok<NOPTS>
    
    for j=1:length(SliceRange(View(i),:))
        
        SliceNumber = SliceRange(View(i),j);
        
        % Gets a single slice of data
        % Bmap_N_S = Difference between betas
        % Tmap_N_S = T-statistics 
        % Pmap_N_S = Binary map 
        % Underlay = Structural image 
         
        switch View(i)
            case 1
                Underlay = fliplr(rot90(squeeze(Structural(SliceNumber,:,:))));
                Bmap_N_S = fliplr(rot90(squeeze(BetaDifference(SliceNumber,:,:))));
                Tmap_N_S = fliplr(rot90(squeeze(TValues(SliceNumber,:,:))));
                if Contour && ~strcmp(ContourFile,'')
                    Pmap_N_S = fliplr(rot90(squeeze(Contour_Mask(SliceNumber,:,:))));
                end
                
                SliceType = 'Sagital_Slice_X=';
                F = figure('Color', 'k', 'Units', 'Normalized', 'Position', Position(View(i),:));
                
            case 2
                Underlay = fliplr(rot90(squeeze(Structural(:,SliceNumber,:))));
                Bmap_N_S = fliplr(rot90(squeeze(BetaDifference(:,SliceNumber,:))));
                Tmap_N_S = fliplr(rot90(squeeze(TValues(:,SliceNumber,:))));
                if Contour && ~strcmp(ContourFile,'')
                    Pmap_N_S = fliplr(rot90(squeeze(Contour_Mask(:,SliceNumber,:))));
                end
                
                SliceType = 'Frontal_Slice_Y=';
                F = figure('Color', 'k', 'Units', 'Normalized', 'Position', Position(View(i),:));
                
            case 3
                Underlay = fliplr(rot90(Structural(:,:,SliceNumber)));
                Bmap_N_S = fliplr(rot90(BetaDifference(:,:,SliceNumber)));
                Tmap_N_S = fliplr(rot90(TValues(:,:,SliceNumber)));
                if Contour && ~strcmp(ContourFile,'')
                    Pmap_N_S = fliplr(rot90(Contour_Mask(:,:,SliceNumber)));
                end
                SliceType = 'Axial_Slice_Z=';
                F = figure('Color', 'k', 'Units', 'Normalized', 'Position', Position(View(i),:));
                
        end
        
        axes('Position', [0 0 1 1]); %#ok<LAXES>
        
        % Transform the underlay and beta map to RGB values, based on specified colormaps
        % See function convert_to_RGB() for more information
        U_RGB = convert_to_RGB(Underlay, CM_under, H_RangeStruc);
        O_RGB = convert_to_RGB(Bmap_N_S, CM_over, H_range);
        
        % Plot the underlay
        layer1 = image(U_RGB); axis image
        hold on;
        % Now, add the Beta difference map as an overlay
        layer2 = image(O_RGB); axis image
        
        % Use the T-statistics to create an alpha map (which must be in [0,1])
        alphamap = abs(Tmap_N_S);
        alphamap(alphamap > A_range(2)) = A_range(2);
        alphamap(alphamap < A_range(1)) = 0;
        alphamap = alphamap/A_range(2); % Normlize
        % Adjust the alpha values of the overlay
        set(layer2, 'alphaData', alphamap);
        
        % Add some (black) contours to annotate nominal significance
        hold on;
        if Contour 
            if strcmp(ContourFile,'')
                [C, CH] = contour(Tmap_N_S>=ContourThreshold, 1, 'k', 'linewidth', 4);
            else
                [C, CH] = contour(Pmap_N_S, 1, 'k', 'linewidth', 4);
            end
        end
        
        % Other details
        box off
        axis off
        
        % Print the figure
        if PrintFig
            if FirstFig 
                ExportFormat=hgexport('readstyle','default');
                ExportFormat.Format = 'tiff';
                ExportFormat.Background = Color;
                FirstFig=0;
            end
            hgexport(gcf, strcat(SliceType, num2str(SliceNumber), '.tif'), ExportFormat);
        end
    end

end



%% Create a 2D colorbar for the dual-coded overlay
G = figure('color', [.5 .5 .5], 'Units', 'Normalized', 'Position', [0.5, 0.4, 0.06, 0.35]);
x = linspace(A_range(1), A_range(2), 256);

% x represents the range in alpha (abs(t-stats))
y = linspace(H_range(1), H_range(2), size(CM_over,1));

% y represents the range in hue (beta weight difference)
[X,Y] = meshgrid(x,y); % Transform into a 2D matrix

axis xy;
box on
xlabel(alpha_label)
ylabel(hue_label)
set(gca, 'Xcolor', 'k', 'Ycolor', 'k')
set(gca, 'YAxisLocation', 'right')

print(gcf, strcat('Activation_', SPM.xCon(1,str2double(ContrastNumber)).name, '_Legend.eps'), '-dpsc2')


% Plot the colorbar
imagesc(x,y,Y); 
colormap(CM_over);
alpha(X);
alpha('scaled');

print(gcf, strcat('Activation_', SPM.xCon(1,str2double(ContrastNumber)).name, '_Legend.tif'), '-dtiffnocompression')


axis off

print(gcf, strcat('Activation_', SPM.xCon(1,str2double(ContrastNumber)).name, '_Legend_NoAxis.tif'), '-dtiffnocompression')
